<html>
<head>
    <!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.8.3/css/mdb.min.css" rel="stylesheet">
    </head>
    <body>


        <form method="post" action="<?php echo e(route('image')); ?>" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>


    	<?php if(count($errors)>0): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger">
        <?php echo e($error); ?>

    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
            <?php if($massege = Session::get('success')): ?>
            <div class="alert alert-success">
        <?php echo e($massege); ?>

    </div>
        <?php endif; ?>
          
                image upload
        <input type="file" name="image"/>
         <input type="submit" name="submit"/>
         
   
</form>
</body>

</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/imgupload/resources/views/index.blade.php ENDPATH**/ ?>