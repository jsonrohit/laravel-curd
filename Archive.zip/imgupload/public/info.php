<?php


echo phpinfo();


?>