<?php

// namespace App;


// use Illuminate\Notifications\Notifiable;
// use Illuminate\Contracts\Auth\MustVerifyEmail;
// use Illuminate\Foundation\Auth\User as Authenticatable;

// use Illuminate\Database\Eloquent\Model;
// use session; 

// class imgmodel extends Model
// {
//     protected $fillable = [
//         'image','size',
//     ];
// }



namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use session;

class imgmodel extends Authenticatable
{
    

    protected $fillable = [
        'image',
    ];
}
    