<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\imgmodel;
use App\session;

class imgcontroller extends Controller
{

     public function image()
    {
        return view('index');
    }

     public function imgupload(Request $request) {

              $user = new imgmodel([
            'image' => $request->get('image'),
            // 'size' =>$request->get('s')
        ]);

 
// print_r($use);
// die();
    //     $this->validate($request, [
    //     'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:4096',
    // ]);


        if ($request->hasFile('image')){
        $image = $request->file('image');
        // $name = $image->getClientOriginalName();
        // $size = $image->getClientSize();
        $name = rand().'.'.$image->getClientOriginalExtension();
        $destinationPath = public_path('images');
        $image->move($destinationPath, $name);
    }
    else 
    {
        echo 'not working';
        return view('index');
    }
        // $this->save();
        // $this->save();
        
       
      
        $user->save();
         // return back()->with('success','Image Upload successfully');

        // return view('index');

}
}
