 <?php echo $__env->make('nic/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <div class="container">


        <div class="row">
            <h1 class="head" style="padding-bottom: 32px;text-align: center;">Update Data</h1>
        </div>
        <div class="row">
            <div class="col-md-4">
             <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(route('user.updated',['id'=>$data->id])); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                       
                                   <div class="form-group">
                                     <label for="email">Email address:</label>
                                     <input type="email" value="<?php echo e($data->email); ?>" placeholder="email" name="email" class="form-control" id="email">
                                   </div>
                                   <div class="form-group">
                                     <label for="pwd">Highest Qualification:</label>
                                     <input type="text" value="<?php echo e($data->qulification); ?>" placeholder="Qualification" name="qualification" class="form-control" id="qualification">
                                   </div>

                                   <button type="submit" class="btn btn-default">Submit</button>

                    </form>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>

    </div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/demo/resources/views/update.blade.php ENDPATH**/ ?>