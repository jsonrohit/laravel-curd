<?php echo $__env->make('nic.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <div class="container">


        <div class="row">
            <h1 class="head" style="padding-bottom: 32px;text-align: center;">Laravel CURD Operation</h1>
        </div>
        <div class="row">
            <div class="col-md-4">
                    
                    <form action="<?php echo e(route('register')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                                   <div class="form-group">
                                     <label for="email">Email address:</label>
                                     <input type="email" placeholder="email" name="email" class="form-control" id="email">
                                   </div>
                                   <div class="form-group">
                                     <label for="pwd">Highest Qualification:</label>
                                     <input type="text" placeholder="Qualification" name="qualification" class="form-control" id="qualification">
                                   </div>
                                   <button type="submit" class="btn btn-default">Submit</button>
                                 </form>
            </div>

        </div>


          <div class="row" style="margin-top:20px;">
           <?php if(empty(!$user)): ?>
             <table class="table">
               <thead>
                 <tr>
                 	<th scope="col">ID</th>
                 	<th scope="col">Email</th>
                   <th scope="col">Qualification</th>
                   <th scope="col">Action</th>
                 </tr>
               </thead>
               <tbody>
               <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                 	<td><?php echo e($data->id); ?></td>
                 	<td><?php echo e($data->email); ?></td>
                   <td><?php echo e($data->qulification); ?></td>
                   <td>
                   
                    <a href="<?php echo e(route('user.delete',['id'=>$data->id])); ?>"><button type="button" class="badge badge-danger" >Delete</button></a>
                    <a href="<?php echo e(route('user.update',['id'=>$data->id])); ?>"><button type="button" class="badge badge-success" >Update</button></a>
                    </td>   
                 </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
             </table>
             <?php endif; ?>
        </div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/demo/resources/views/index.blade.php ENDPATH**/ ?>