<?php echo $__env->make('nic.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<html>
<body>
	<!-- Default form subscription -->
<form class="text-center border border-light p-5">
    <div class="row ">
		        <div class="col-md-3">	 
		           <p class="h4 mb-5"><u>Curd Opretion</u></p>
		       </div>
		     <div class="col-md-5 mt-5">
		    <input type="text" id="" class="form-control mb-4" placeholder="Name">
		    <input type="text" id="" class="form-control mb-4" placeholder="Class">
		    <div class="row">
		    	<div class="col-md-8">
		    </div>
		    	<div class="col-md-4">
		    		<button class="btn btn-success my-4" type="submit">Sign in</button>
		    </div>
		</div>
		    
		    </div>
		      <div class="col-md-4"></div>
	 </div>
</form>

 <div class="row ">
     <div class="col-md-3">
     	</div>
     	<div class="col-md-6">
<table class="table">
<thead>
<tr>
<th>Header 1</th>
<th>Header 2</th>
<th>Header 3</th>
<th>Action</th>
</tr>
</thead>
<tr>
	
<td>Cell</td>
<td>Cell</td>
<td>Cell</td>
<th><a href="(<?php echo e(url('edit')); ?>" class = " badge badge-success">Edit</a>
<a href="(<?php echo e(url('delete')); ?>" class = "badge badge-info">Delete</a>
</tr>
</tbody>
</table>
</div>
<div class="col-md-3">
     	</div>

 
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/demo/resources/views/home.blade.php ENDPATH**/ ?>