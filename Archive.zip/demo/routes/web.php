<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('index');
// });
Route::get('/','Controller@index');

Route::post('/register','Controller@insert')->name('register');
// Route::get('/register', 'Controller@display')->name('register');
Route::get('/delete/{id}','Controller@delete')->name('user.delete');

Route::get('/update/{id}','Controller@update')->name('user.update');
Route::post('/update/{id}','Controller@updateclient')->name('user.updated');
