@include('nic.header')
 <div class="container">


        <div class="row">
            <h1 class="head" style="padding-bottom: 32px;text-align: center;">Laravel CURD Operation</h1>
        </div>
        <div class="row">
            <div class="col-md-4">
                    
                    <form action="{{route('register')}}" method="post">
                        {{ csrf_field() }}
                                   <div class="form-group">
                                     <label for="email">Email address:</label>
                                     <input type="email" placeholder="email" name="email" class="form-control" id="email">
                                   </div>
                                   <div class="form-group">
                                     <label for="pwd">Highest Qualification:</label>
                                     <input type="text" placeholder="Qualification" name="qualification" class="form-control" id="qualification">
                                   </div>
                                   <button type="submit" class="btn btn-default">Submit</button>
                                 </form>
            </div>

        </div>


          <div class="row" style="margin-top:20px;">
           @if(empty(!$user))
             <table class="table">
               <thead>
                 <tr>
                 	<th scope="col">ID</th>
                 	<th scope="col">Email</th>
                   <th scope="col">Qualification</th>
                   <th scope="col">Action</th>
                 </tr>
               </thead>
               <tbody>
               @foreach($user as $data)
                 <tr>
                 	<td>{{$data->id}}</td>
                 	<td>{{$data->email}}</td>
                   <td>{{$data->qulification}}</td>
                   <td>
                   
                    <a href="{{route('user.delete',['id'=>$data->id])}}"><button type="button" class="badge badge-danger" >Delete</button></a>
                    <a href="{{route('user.update',['id'=>$data->id])}}"><button type="button" class="badge badge-success" >Update</button></a>
                    </td>   
                 </tr>
               @endforeach
               </tbody>
             </table>
             @endif
        </div>