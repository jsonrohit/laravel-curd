<?php
namespace App;
 
 use Illuminate\database\modal;
 class curd extends model
 {
 	protected $abc = [	
 		'name', 'father'];
 }
?>