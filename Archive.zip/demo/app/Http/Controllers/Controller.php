<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use App\User;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;


 public function index()
    {
            $Userdata = User::select('*')->get();

            // echo '<pre>';
            // print_r($Userdata->toArray());
            // die();

            return view('index')->with(['user' => $Userdata]);
    }
      
     public function insert(Request $request) {
        $User = new User([
                                    'email' => $request->get('email'),
                                    'qulification' => $request->get('qualification')
                         ]);
                         $User->save();
                         $Userdata = User::select('*')->get();
                 return view('index')->with(['user' => $Userdata]);
                         // echo "Record inserted successfully.<br/>";
           // return view('index');	
    }
      public function delete(Request $request)
          {

                    User::where('id',$request->id)->delete();
                    $Clientdata = User::select('*')->get();
                    return view('index')->with(['user' => $Clientdata]);
          }
           public function update(Request $request)
     {
         $Clientdata = User::where('id',$request->id)->get();
         return view('update')->with(['user' => $Clientdata]);
     }

      public function updateclient(Request $request)
      {
            User::where('id',$request->id)->update(
                [
                  'email' => $request->get('email'),
                  'qulification' => $request->get('qualification')
                ]
              );
            $Clientdata = User::select('*')->get();
            return view('index')->with(['user' => $Clientdata]);
      }

}